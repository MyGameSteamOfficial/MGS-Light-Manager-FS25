bl_info = {
    'name': 'MGS Light Manager for FS25',
    'author': 'MyGameSteam',
    'blender': (3, 0, 0),
    'version': (1, 0, 0),
    'description': 'A plugin for managing light types and UV adjustments in Farming Simulator 25.',
    'warning': 'This tool modifies UV maps directly. Use with caution.',
    'location': 'UV/Image Editor > Tools',
    'category': 'Game Engine',
    'license': 'GPL-3.0'
}

# Licensed under the GNU General Public License, version 3 (GPLv3)
# Full license text available in the LICENSE file or at https://www.gnu.org/licenses/gpl-3.0.txt


import bpy
import math
import mathutils


def init_scene_properties(scn):
    print("MGS Light Manager for FS25 Loaded")
    return


class MGS_PT_LightPanel(bpy.types.Panel):
    button1 = "Default Light"
    button2 = "Default Light & High Beam"
    button3 = "High Beam"
    button4 = "Bottom Light"
    button5 = "Top Light"
    button6 = "DRL"
    button7 = "Turn Light Left"
    button8 = "Turn Light Right"

    button9 = "Back Light"
    button10 = "Brake Light"
    button11 = "Back & Brake Light"
    button12 = "Reverse Light"
    button13 = "Work Light Front"
    button14 = "Work Light Back"
    button15 = "Work Light Additional"
    button16 = "Work Light Additional 2"

    bl_label = "MGS Light Types"
    bl_space_type = 'IMAGE_EDITOR'
    bl_region_type = "TOOLS"

    def draw(self, context):
        layout = self.layout
        
        layout.label(text="Selectable Light Type")

        row = layout.row()
        col_left = row.column()
        col_right = row.column()

        col_left.operator("mgs.move_light", icon='LIGHT', text=self.button1).location = "0 / 0"
        col_left.operator("mgs.move_light", icon='LIGHT', text=self.button2).location = "1 / 0"
        col_left.operator("mgs.move_light", icon='LIGHT', text=self.button3).location = "2 / 0"
        col_left.operator("mgs.move_light", icon='LIGHT', text=self.button4).location = "3 / 0"
        col_left.operator("mgs.move_light", icon='LIGHT', text=self.button5).location = "4 / 0"
        col_left.operator("mgs.move_light", icon='LIGHT', text=self.button6).location = "5 / 0"
        col_left.operator("mgs.move_light", icon='LIGHT', text=self.button7).location = "6 / 0"
        col_left.operator("mgs.move_light", icon='LIGHT', text=self.button8).location = "7 / 0"

        col_right.operator("mgs.move_light", icon='LIGHT', text=self.button9).location = "0 / 1"
        col_right.operator("mgs.move_light", icon='LIGHT', text=self.button10).location = "1 / 1"
        col_right.operator("mgs.move_light", icon='LIGHT', text=self.button11).location = "2 / 1"
        col_right.operator("mgs.move_light", icon='LIGHT', text=self.button12).location = "3 / 1"
        col_right.operator("mgs.move_light", icon='LIGHT', text=self.button13).location = "4 / 1"
        col_right.operator("mgs.move_light", icon='LIGHT', text=self.button14).location = "5 / 1"
        col_right.operator("mgs.move_light", icon='LIGHT', text=self.button15).location = "6 / 1"
        col_right.operator("mgs.move_light", icon='LIGHT', text=self.button16).location = "7 / 1"
        layout.separator()

        layout.label(text="Move UV:")

        col_main = layout.column(align=True)

        row_top = col_main.row(align=True)
        row_top.scale_y = 1.5
        row_top.alignment = 'CENTER'
        row_top.operator("mgs.move_up", icon='TRIA_UP', text="")

        row_middle = col_main.row(align=True)
        row_middle.alignment = 'CENTER'
        row_middle.operator("mgs.move_left", icon='TRIA_LEFT', text="")
        row_middle.operator("mgs.move_center", text="●", emboss=False)
        row_middle.operator("mgs.move_right", icon='TRIA_RIGHT', text="")

        row_bottom = col_main.row(align=True)
        row_bottom.scale_y = 1.5
        row_bottom.alignment = 'CENTER'
        row_bottom.operator("mgs.move_down", icon='TRIA_DOWN', text="")


class MGS_OT_MoveDown(bpy.types.Operator):
    bl_idname = 'mgs.move_down'
    bl_label = 'Move Light Down'
    bl_space_type = 'IMAGE_EDITOR'

    def invoke(self, context, event):
        bpy.ops.transform.translate(value=(0.0, -1.0, 0.0))
        return {"FINISHED"}


class MGS_OT_MoveUp(bpy.types.Operator):
    bl_idname = 'mgs.move_up'
    bl_label = 'Move Light Up'
    bl_space_type = 'IMAGE_EDITOR'

    def invoke(self, context, event):
        bpy.ops.transform.translate(value=(0.0, 1.0, 0.0))
        return {"FINISHED"}


class MGS_OT_MoveLeft(bpy.types.Operator):
    bl_idname = 'mgs.move_left'
    bl_label = 'Move Light Left'
    bl_space_type = 'IMAGE_EDITOR'

    def invoke(self, context, event):
        bpy.ops.transform.translate(value=(-1.0, 0.0, 0.0))
        return {"FINISHED"}


class MGS_OT_MoveRight(bpy.types.Operator):
    bl_idname = 'mgs.move_right'
    bl_label = 'Move Light Right'
    bl_space_type = 'IMAGE_EDITOR'

    def invoke(self, context, event):
        bpy.ops.transform.translate(value=(1.0, 0.0, 0.0))
        return {"FINISHED"}


class MGS_OT_MoveCenter(bpy.types.Operator):
    bl_idname = 'mgs.move_center'
    bl_label = 'Center Light'
    bl_space_type = 'IMAGE_EDITOR'

    def invoke(self, context, event):
        bpy.ops.transform.translate(value=(0.0, 0.0, 0.0))
        return {"FINISHED"}


class MGS_OT_MoveLight(bpy.types.Operator):
    bl_idname = 'mgs.move_light'
    bl_label = 'Move Light to Custom Location'
    bl_space_type = 'IMAGE_EDITOR'
    location: bpy.props.StringProperty()

    def execute(self, context):
        x2_location, y2_location = self.location.split(('/'))
        mover = MGS_OT_Mover
        mover.move_me(self, context, float(x2_location), float(y2_location))
        return {"FINISHED"}


class MGS_OT_Mover(bpy.types.Operator):
    bl_idname = 'mgs.move_mover'
    bl_label = 'Move Light to Specific Location'
    bl_space_type = 'IMAGE_EDITOR'
    location: bpy.props.StringProperty()

    def move_me(self, context, x_location, y_location):
        bpy.context.area.type = 'IMAGE_EDITOR'
        target = [x_location, y_location]
        current = [0.0, 0.0]
        move = [0.0, 0.0]

        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.uv.select_all(action='SELECT')
        bpy.ops.object.mode_set(mode='OBJECT')

        uvs = context.object.data.uv_layers.active.data

        for uv in uvs:
            if uv.select:
                current[0] += uv.uv[0]
                current[1] += uv.uv[1]
                move[0] = target[0] - math.floor(current[0])
                move[1] = target[1] - math.floor(current[1])
                break

        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.transform.translate(value=(move[0], move[1], 0.0))
        bpy.ops.uv.select_all(action='DESELECT')
        return {"FINISHED"}


classes = (
    MGS_PT_LightPanel,
    MGS_OT_MoveDown,
    MGS_OT_MoveUp,
    MGS_OT_MoveLeft,
    MGS_OT_MoveRight,
    MGS_OT_MoveCenter,
    MGS_OT_MoveLight,
    MGS_OT_Mover
)

register, unregister = bpy.utils.register_classes_factory(classes)
